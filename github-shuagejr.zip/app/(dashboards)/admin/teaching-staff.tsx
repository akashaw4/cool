import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Platform,
  Alert,
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useFirebase } from '@/context/FirebaseContext';
import { Upload, UserPlus, Search, Trash2, SquarePen as PenSquare } from 'lucide-react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as XLSX from 'xlsx';

interface TeachingStaff {
  id: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  joiningDate: string;
  subjects: string[];
  isVerified?: boolean;
}

export default function TeachingStaffScreen() {
  const { isDark } = useTheme();
  const { createUser } = useFirebase();
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [staffList, setStaffList] = useState<TeachingStaff[]>([]);
  const [newStaff, setNewStaff] = useState({
    name: '',
    email: '',
    phone: '',
    department: '',
    designation: '',
    subjects: '',
  });
  const [loading, setLoading] = useState(false);

  const handleImportExcel = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });

      if (result.assets && result.assets[0]) {
        const asset = result.assets[0];
        if (Platform.OS === 'web') {
          const response = await fetch(asset.uri);
          const blob = await response.blob();
          const reader = new FileReader();
          reader.onload = (e) => {
            const data = new Uint8Array(e.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet);
            
            const newStaffList = jsonData.map((row: any) => ({
              id: Math.random().toString(36).substr(2, 9),
              name: row.name || '',
              email: row.email || '',
              phone: row.phone || '',
              department: row.department || '',
              designation: row.designation || '',
              subjects: row.subjects ? row.subjects.split(',') : [],
              joiningDate: new Date().toISOString().split('T')[0],
            }));

            setStaffList([...staffList, ...newStaffList]);
          };
          reader.readAsArrayBuffer(blob);
        }
      }
    } catch (error) {
      console.error('Error importing Excel file:', error);
    }
  };

  const handleAddStaff = async () => {
    try {
      setLoading(true);
      await createUser(newStaff.email, 'teaching_staff');

      const staffMember: TeachingStaff = {
        id: Math.random().toString(36).substr(2, 9),
        ...newStaff,
        subjects: newStaff.subjects.split(',').map(s => s.trim()),
        joiningDate: new Date().toISOString().split('T')[0],
        isVerified: false,
      };

      setStaffList([...staffList, staffMember]);
      setNewStaff({
        name: '',
        email: '',
        phone: '',
        department: '',
        designation: '',
        subjects: '',
      });
      setShowAddForm(false);
      Alert.alert(
        'Success',
        'Staff member added successfully. A verification email has been sent.'
      );
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredStaff = staffList.filter(
    (staff) =>
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <ScrollView style={[styles.container, { backgroundColor: isDark ? '#000000' : '#F2F2F7' }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: isDark ? '#FFFFFF' : '#000000' }]}>
          Teaching Staff Management
        </Text>
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: isDark ? '#1C1C1E' : '#FFFFFF' }]}
            onPress={handleImportExcel}>
            <Upload size={20} color={isDark ? '#0A84FF' : '#007AFF'} />
            <Text style={[styles.buttonText, { color: isDark ? '#0A84FF' : '#007AFF' }]}>
              Import Excel
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: isDark ? '#1C1C1E' : '#FFFFFF' }]}
            onPress={() => setShowAddForm(true)}>
            <UserPlus size={20} color={isDark ? '#0A84FF' : '#007AFF'} />
            <Text style={[styles.buttonText, { color: isDark ? '#0A84FF' : '#007AFF' }]}>
              Add Staff
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <View
        style={[
          styles.searchContainer,
          { backgroundColor: isDark ? '#1C1C1E' : '#FFFFFF' },
        ]}>
        <Search size={20} color={isDark ? '#8E8E93' : '#8E8E93'} />
        <TextInput
          style={[styles.searchInput, { color: isDark ? '#FFFFFF' : '#000000' }]}
          placeholder="Search teaching staff..."
          placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {showAddForm && (
        <View style={[styles.formContainer, { backgroundColor: isDark ? '#1C1C1E' : '#FFFFFF' }]}>
          <Text style={[styles.formTitle, { color: isDark ? '#FFFFFF' : '#000000' }]}>
            Add New Teaching Staff
          </Text>
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Name"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.name}
            onChangeText={(text) => setNewStaff({ ...newStaff, name: text })}
          />
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Email"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.email}
            onChangeText={(text) => setNewStaff({ ...newStaff, email: text })}
            keyboardType="email-address"
          />
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Phone"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.phone}
            onChangeText={(text) => setNewStaff({ ...newStaff, phone: text })}
            keyboardType="phone-pad"
          />
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Department"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.department}
            onChangeText={(text) => setNewStaff({ ...newStaff, department: text })}
          />
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Designation"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.designation}
            onChangeText={(text) => setNewStaff({ ...newStaff, designation: text })}
          />
          <TextInput
            style={[styles.input, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7', color: isDark ? '#FFFFFF' : '#000000' }]}
            placeholder="Subjects (comma-separated)"
            placeholderTextColor={isDark ? '#8E8E93' : '#8E8E93'}
            value={newStaff.subjects}
            onChangeText={(text) => setNewStaff({ ...newStaff, subjects: text })}
          />
          <View style={styles.formActions}>
            <TouchableOpacity
              style={[styles.button, { backgroundColor: isDark ? '#FF453A' : '#FF3B30' }]}
              onPress={() => setShowAddForm(false)}
              disabled={loading}>
              <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.button,
                { 
                  backgroundColor: loading 
                    ? isDark ? '#1C1C1E' : '#E5E5EA'
                    : isDark ? '#30D158' : '#34C759'
                }
              ]}
              onPress={handleAddStaff}
              disabled={loading}>
              <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>
                {loading ? 'Adding...' : 'Save'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <View style={styles.staffList}>
        {filteredStaff.map((staff) => (
          <View
            key={staff.id}
            style={[
              styles.staffCard,
              { backgroundColor: isDark ? '#1C1C1E' : '#FFFFFF' },
            ]}>
            <View style={styles.staffInfo}>
              <Text style={[styles.staffName, { color: isDark ? '#FFFFFF' : '#000000' }]}>
                {staff.name}
              </Text>
              <Text style={[styles.staffDetails, { color: isDark ? '#8E8E93' : '#6B7280' }]}>
                {staff.designation} • {staff.department}
              </Text>
              <Text style={[styles.staffContact, { color: isDark ? '#8E8E93' : '#6B7280' }]}>
                {staff.email} • {staff.phone}
              </Text>
              <Text style={[styles.staffSubjects, { color: isDark ? '#8E8E93' : '#6B7280' }]}>
                Subjects: {staff.subjects.join(', ')}
              </Text>
            </View>
            <View style={styles.staffActions}>
              <TouchableOpacity style={styles.actionButton}>
                <PenSquare size={20} color={isDark ? '#0A84FF' : '#007AFF'} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton}>
                <Trash2 size={20} color={isDark ? '#FF453A' : '#FF3B30'} />
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    gap: 8,
  },
  buttonText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 20,
    padding: 12,
    borderRadius: 8,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
  },
  formContainer: {
    margin: 20,
    padding: 16,
    borderRadius: 12,
  },
  formTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 16,
  },
  input: {
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
  },
  formActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 16,
  },
  staffList: {
    padding: 20,
  },
  staffCard: {
    flexDirection: 'row',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  staffInfo: {
    flex: 1,
  },
  staffName: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  staffDetails: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
  },
  staffContact: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
  },
  staffSubjects: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
  },
  staffActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  actionButton: {
    padding: 8,
  },
});